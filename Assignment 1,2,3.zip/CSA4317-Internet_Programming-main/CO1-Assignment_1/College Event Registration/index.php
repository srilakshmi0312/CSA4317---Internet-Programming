<?php
/**
 * TECHNOVATE 2026 - Official College Technical & Cultural Symposium Portal
 * Dates: 26–28 December 2026
 * Technologies: HTML5, CSS3, JavaScript, PHP, MySQL (PDO)
 * Compatible with: WAMP, LAMP, XAMPP, and PHP Built-in Server.
 */
session_start();
$flash_success = $_SESSION['registration_success'] ?? null;
$flash_error   = $_SESSION['flash_error'] ?? null;
$form_data     = $_SESSION['form_data'] ?? [];

// Clear flash messages after reading
unset($_SESSION['registration_success'], $_SESSION['flash_error'], $_SESSION['form_data']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>TECHNOVATE 2026 | National Technical & Cultural Symposium (26–28 Dec 2026)</title>
  <meta name="description" content="TECHNOVATE 2026 - 26 to 28 December 2026. National Technical & Cultural Symposium. Technical coding battles, robotics arenas, paper presentations, plus 10 thrilling non-technical events!">
  <link rel="icon" type="image/svg+xml" href="images/favicon.svg">

  <!-- Google Web Fonts: Outfit, Inter, Orbitron -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Orbitron:wght@500;700;900&family=Outfit:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">

  <!-- Font Awesome 6 Icons CDN -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

  <!-- REQUIREMENT 5 (CSS3): External CSS in a separate stylesheet -->
  <link rel="stylesheet" href="style.css">

  <!-- ========================================================
       REQUIREMENT 5 (CSS3): Internal CSS using a <style> tag
       Demonstrating internal CSS rules, custom keyframe glow, 
       and specific priority component overrides.
       ======================================================== -->
  <style>
    /* Internal CSS Demonstration */
    .internal-badge-highlight {
      position: relative;
      display: inline-block;
      padding: 2px 10px;
      border-radius: 4px;
      font-weight: 700;
      color: #00f0ff;
      background: rgba(0, 240, 255, 0.1);
      border-left: 3px solid #00f0ff;
    }

    @keyframes pulseInternalGlow {
      0% {
        box-shadow: 0 0 10px rgba(0, 240, 255, 0.3);
      }
      50% {
        box-shadow: 0 0 25px rgba(139, 92, 246, 0.6);
      }
      100% {
        box-shadow: 0 0 10px rgba(0, 240, 255, 0.3);
      }
    }

    .internal-animated-glow {
      animation: pulseInternalGlow 3s infinite ease-in-out;
    }
  </style>
</head>
<body>

  <!-- ========================================================
       SECTION A: Navigation Bar
       Semantic Element: <header> and <nav>
       ======================================================== -->
  <header class="header-nav" id="navbar">
    <nav class="nav-container container" aria-label="Main Navigation">
      <!-- Logo & Branding -->
      <a href="#home" class="nav-brand" aria-label="TECHNOVATE 2026 Home">
        <img src="images/logo.svg" alt="TECHNOVATE 2026 Logo" class="nav-logo-img">
      </a>

      <!-- Navigation Links -->
      <ul class="nav-menu" id="nav-menu">
        <li><a href="#home" class="nav-link active">Home</a></li>
        <li><a href="#about" class="nav-link">About</a></li>
        <li><a href="#events" class="nav-link">Technical Events</a></li>
        <li><a href="#non-tech-events" class="nav-link">Non-Technical</a></li>
        <li><a href="#schedule" class="nav-link">Schedule</a></li>
        <li><a href="#register" class="nav-link">Register</a></li>
        <li><a href="#contact" class="nav-link">Contact</a></li>
      </ul>

      <!-- Action Button & Hamburger Toggle -->
      <div class="nav-actions">
        <a href="#register" class="btn btn-primary btn-sm">
          <i class="fa-solid fa-bolt"></i> Register Now
        </a>
        <button class="hamburger" id="hamburger" aria-label="Toggle mobile menu" aria-expanded="false">
          <span class="hamburger-line"></span>
          <span class="hamburger-line"></span>
          <span class="hamburger-line"></span>
        </button>
      </div>
    </nav>
  </header>


  <main id="main-content">
    <!-- ========================================================
         SECTION B: Hero Section
         Dates Updated: 26–28 December 2026
         ======================================================== -->
    <section class="hero-section" id="home">
      <!-- Interactive HTML5 Canvas Particle Network -->
      <canvas id="hero-canvas" aria-hidden="true"></canvas>

      <div class="container hero-grid">
        <div class="hero-content">
          <!-- REQUIREMENT 5 (CSS3): Inline CSS demonstration on a live element -->
          <div class="hero-pill-badge internal-animated-glow" 
               style="border-color: rgba(0, 240, 255, 0.6); box-shadow: 0 0 18px rgba(0, 240, 255, 0.35); letter-spacing: 1.5px;">
            <span class="live-pulse"></span>
            <span>NATIONAL LEVEL SYMPOSIUM • 10TH EDITION</span>
          </div>

          <!-- Main Heading -->
          <h1 class="hero-title">
            INNOVATE. <span class="gradient-text">COMPETE.</span> CREATE.
          </h1>

          <!-- Subtitle -->
          <p class="hero-subtitle">
            <i class="fa-solid fa-microchip"></i> The Ultimate Technical & Cultural Symposium 2026
          </p>

          <p class="hero-description">
            Experience 3 electrifying days of innovation, high-octane coding arenas, autonomous robotics battles, breakthrough paper presentations, and 10 sensational cultural and non-technical competitions.
          </p>

          <!-- Event Date & College Location Metadata (Updated to 26–28 December 2026) -->
          <div class="hero-meta">
            <div class="meta-item">
              <i class="fa-regular fa-calendar-days meta-icon"></i>
              <span><strong>26–28 December 2026</strong></span>
            </div>
            <div class="meta-item">
              <i class="fa-solid fa-location-dot meta-icon"></i>
              <span><strong>Apex Institute of Technology, Innovation Campus</strong></span>
            </div>
          </div>

          <!-- Hero Action Buttons -->
          <div class="hero-actions">
            <a href="#events" class="btn btn-secondary">
              <i class="fa-solid fa-layer-group"></i> Technical Events
            </a>
            <a href="#non-tech-events" class="btn btn-nontech">
              <i class="fa-solid fa-masks-theater"></i> Non-Technical Events
            </a>
            <a href="#register" class="btn btn-primary">
              <i class="fa-solid fa-user-plus"></i> Register Now
            </a>
          </div>

          <!-- Live Event Countdown Timer (Target: 26 December 2026 at 9:00 AM IST) -->
          <div class="countdown-box">
            <div class="countdown-label">
              <i class="fa-regular fa-clock"></i> Symposium Starts In: (26 Dec 2026, 9:00 AM IST)
            </div>
            <div class="countdown-timer" id="countdownTimer">
              <div class="time-card">
                <span class="time-num" id="count-days">00</span>
                <span class="time-lbl">Days</span>
              </div>
              <span class="time-divider">:</span>
              <div class="time-card">
                <span class="time-num" id="count-hours">00</span>
                <span class="time-lbl">Hours</span>
              </div>
              <span class="time-divider">:</span>
              <div class="time-card">
                <span class="time-num" id="count-minutes">00</span>
                <span class="time-lbl">Mins</span>
              </div>
              <span class="time-divider">:</span>
              <div class="time-card">
                <span class="time-num" id="count-seconds">00</span>
                <span class="time-lbl">Secs</span>
              </div>
            </div>
          </div>
        </div>

        <!-- Hero Graphic Visual -->
        <div class="hero-visual">
          <div class="hero-image-wrapper">
            <img src="images/hero-tech.svg" alt="Technovate 2026 Futuristic Visual" class="hero-main-img">
          </div>
        </div>
      </div>
    </section>


    <!-- ========================================================
         SECTION C: About Section
         ======================================================== -->
    <section class="section about-section" id="about">
      <div class="container">
        <div class="section-header">
          <span class="section-tag"><i class="fa-solid fa-atom"></i> About The Fest</span>
          <h2 class="section-title">Where Vision Meets <span class="gradient-text">Technological Mastery</span></h2>
          <p class="section-subtitle">Join us on 26–28 December 2026 as students from across the country compete in 16 technical and non-technical arenas.</p>
        </div>

        <div class="about-grid">
          <article class="about-content">
            <h3>Pioneering the Next Era of Intelligence</h3>
            <p>
              TECHNOVATE 2026 is the flagship national-level symposium hosted by the Department of Computer Science & Engineering at Apex Institute of Technology. From 26 to 28 December 2026, our campus transforms into an innovation ecosystem.
            </p>
            <p>
              Whether you are architecting deep learning pipelines in the Coding Challenge or expressing your creativity in the Dance Battle, Short Film Festival, or Photography Challenge, TECHNOVATE provides the ultimate arena to prove your skills and win cash prizes.
            </p>

            <ul class="about-features-list">
              <li class="feature-point">
                <span class="feature-check-icon"><i class="fa-solid fa-check"></i></span>
                <span>16 Technical & Cultural Competitions</span>
              </li>
              <li class="feature-point">
                <span class="feature-check-icon"><i class="fa-solid fa-check"></i></span>
                <span>₹2,50,000+ Total Cash Prize Pool</span>
              </li>
              <li class="feature-point">
                <span class="feature-check-icon"><i class="fa-solid fa-check"></i></span>
                <span>Industry Keynotes & VC Mentorship</span>
              </li>
              <li class="feature-point">
                <span class="feature-check-icon"><i class="fa-solid fa-check"></i></span>
                <span>Verified ISO Certificates & Digital Passes</span>
              </li>
            </ul>
          </article>

          <div class="about-visual glass-card" style="padding: 30px; text-align: center;">
            <div style="font-family: var(--font-mono); font-size: 0.9rem; color: var(--cyan); margin-bottom: 15px;">
              // 26–28 DECEMBER 2026 • 3 DAYS OF INNOVATION
            </div>
            <p style="color: var(--text-secondary); margin-bottom: 25px;">
              "Great engineering and art unite here: from algorithmic problem solving to theatrical brilliance and creative film-making."
            </p>
            <div style="display: flex; gap: 15px; justify-content: center; flex-wrap: wrap;">
              <span class="internal-badge-highlight"><i class="fa-solid fa-shield-halved"></i> Merit Certification</span>
              <span class="internal-badge-highlight"><i class="fa-solid fa-trophy"></i> Grand Trophies</span>
              <span class="internal-badge-highlight"><i class="fa-solid fa-handshake"></i> Industry Networking</span>
            </div>
          </div>
        </div>

        <!-- Animated Statistics Counters -->
        <div class="stats-grid">
          <div class="stat-card glass-card">
            <div class="stat-icon"><i class="fa-solid fa-gamepad"></i></div>
            <div class="stat-number-wrapper">
              <span class="stat-counter" data-target="16">0</span>
              <span class="stat-suffix">+</span>
            </div>
            <div class="stat-label">Events & Competitions</div>
          </div>

          <div class="stat-card glass-card">
            <div class="stat-icon"><i class="fa-solid fa-users"></i></div>
            <div class="stat-number-wrapper">
              <span class="stat-counter" data-target="500">0</span>
              <span class="stat-suffix">+</span>
            </div>
            <div class="stat-label">Participants Expected</div>
          </div>

          <div class="stat-card glass-card">
            <div class="stat-icon"><i class="fa-solid fa-building-columns"></i></div>
            <div class="stat-number-wrapper">
              <span class="stat-counter" data-target="20">0</span>
              <span class="stat-suffix">+</span>
            </div>
            <div class="stat-label">Participating Colleges</div>
          </div>

          <div class="stat-card glass-card">
            <div class="stat-icon"><i class="fa-solid fa-calendar-check"></i></div>
            <div class="stat-number-wrapper">
              <span class="stat-counter" data-target="3">0</span>
              <span class="stat-suffix"></span>
            </div>
            <div class="stat-label">Days (26–28 Dec 2026)</div>
          </div>
        </div>
      </div>
    </section>


    <!-- ========================================================
         SECTION D: Technical Events (All 6 Preserved)
         ======================================================== -->
    <section class="section events-section" id="events">
      <div class="container">
        <div class="section-header">
          <span class="section-tag"><i class="fa-solid fa-microchip"></i> Engineering Arenas</span>
          <h2 class="section-title">Technical <span class="gradient-text">Competitions</span></h2>
          <p class="section-subtitle">Six flagship technical championships engineered to test your algorithmic speed, research innovation, and engineering mastery.</p>
        </div>

        <div class="events-grid">
          <!-- Event 1: Paper Presentation -->
          <article class="event-card glass-card">
            <div class="event-card-header">
              <div class="event-icon-box">
                <img src="images/paper-presentation.svg" alt="Paper Presentation Icon">
              </div>
              <span class="event-badge">RESEARCH</span>
            </div>
            <h3 class="event-title">Paper Presentation</h3>
            <p class="event-description">
              Unveil research in Artificial Intelligence, Blockchain, Quantum Computing, IoT, and Cyber Defense before a panel of academic scientists.
            </p>
            <div class="event-specs-list">
              <div class="event-spec-row">
                <span class="spec-key"><i class="fa-solid fa-users"></i> Team:</span>
                <span class="spec-val">1 - 3 Members</span>
              </div>
              <div class="event-spec-row">
                <span class="spec-key"><i class="fa-solid fa-medal"></i> Cash Prize:</span>
                <span class="spec-val prize">₹15,000</span>
              </div>
              <div class="event-spec-row">
                <span class="spec-key"><i class="fa-solid fa-clock"></i> Date & Venue:</span>
                <span class="spec-val">26 Dec 2026 • Seminar Hall A</span>
              </div>
            </div>
            <div class="event-card-actions">
              <button type="button" class="btn btn-secondary btn-sm btn-quick-register" data-event="Paper Presentation">
                <i class="fa-solid fa-plus"></i> Select Event
              </button>
            </div>
          </article>

          <!-- Event 2: Coding Challenge -->
          <article class="event-card glass-card">
            <div class="event-card-header">
              <div class="event-icon-box">
                <img src="images/coding.svg" alt="Coding Challenge Icon">
              </div>
              <span class="event-badge">ALGORITHMS</span>
            </div>
            <h3 class="event-title">Coding Challenge</h3>
            <p class="event-description">
              High-intensity algorithmic programming sprint. Solve complex data structures, dynamic programming problems, and speed tests on the live leaderboard.
            </p>
            <div class="event-specs-list">
              <div class="event-spec-row">
                <span class="spec-key"><i class="fa-solid fa-user"></i> Team:</span>
                <span class="spec-val">Individual (Solo)</span>
              </div>
              <div class="event-spec-row">
                <span class="spec-key"><i class="fa-solid fa-medal"></i> Cash Prize:</span>
                <span class="spec-val prize">₹25,000</span>
              </div>
              <div class="event-spec-row">
                <span class="spec-key"><i class="fa-solid fa-clock"></i> Date & Venue:</span>
                <span class="spec-val">26 Dec 2026 • Computing Lab 3</span>
              </div>
            </div>
            <div class="event-card-actions">
              <button type="button" class="btn btn-secondary btn-sm btn-quick-register" data-event="Coding Challenge">
                <i class="fa-solid fa-plus"></i> Select Event
              </button>
            </div>
          </article>

          <!-- Event 3: Web Development -->
          <article class="event-card glass-card">
            <div class="event-card-header">
              <div class="event-icon-box">
                <img src="images/web-dev.svg" alt="Web Development Icon">
              </div>
              <span class="event-badge">FULL-STACK</span>
            </div>
            <h3 class="event-title">Web Development</h3>
            <p class="event-description">
              4-hour rapid prototyping hackathon. Build a responsive, accessible, and high-performance web application based on a real-time prompt.
            </p>
            <div class="event-specs-list">
              <div class="event-spec-row">
                <span class="spec-key"><i class="fa-solid fa-users"></i> Team:</span>
                <span class="spec-val">1 - 2 Members</span>
              </div>
              <div class="event-spec-row">
                <span class="spec-key"><i class="fa-solid fa-medal"></i> Cash Prize:</span>
                <span class="spec-val prize">₹20,000</span>
              </div>
              <div class="event-spec-row">
                <span class="spec-key"><i class="fa-solid fa-clock"></i> Date & Venue:</span>
                <span class="spec-val">27 Dec 2026 • Software Lab 1</span>
              </div>
            </div>
            <div class="event-card-actions">
              <button type="button" class="btn btn-secondary btn-sm btn-quick-register" data-event="Web Development">
                <i class="fa-solid fa-plus"></i> Select Event
              </button>
            </div>
          </article>

          <!-- Event 4: Robotics -->
          <article class="event-card glass-card">
            <div class="event-card-header">
              <div class="event-icon-box">
                <img src="images/robotics.svg" alt="Robotics Icon">
              </div>
              <span class="event-badge">HARDWARE</span>
            </div>
            <h3 class="event-title">Robotics Challenge</h3>
            <p class="event-description">
              Showcase precision kinematics and sensor control. Includes the Autonomous Line Follower speed sprint and the heavyweight Robo-Sumo arena clash.
            </p>
            <div class="event-specs-list">
              <div class="event-spec-row">
                <span class="spec-key"><i class="fa-solid fa-users"></i> Team:</span>
                <span class="spec-val">2 - 4 Members</span>
              </div>
              <div class="event-spec-row">
                <span class="spec-key"><i class="fa-solid fa-medal"></i> Cash Prize:</span>
                <span class="spec-val prize">₹30,000</span>
              </div>
              <div class="event-spec-row">
                <span class="spec-key"><i class="fa-solid fa-clock"></i> Date & Venue:</span>
                <span class="spec-val">27 Dec 2026 • Indoor Sports Complex</span>
              </div>
            </div>
            <div class="event-card-actions">
              <button type="button" class="btn btn-secondary btn-sm btn-quick-register" data-event="Robotics">
                <i class="fa-solid fa-plus"></i> Select Event
              </button>
            </div>
          </article>

          <!-- Event 5: Tech Quiz -->
          <article class="event-card glass-card">
            <div class="event-card-header">
              <div class="event-icon-box">
                <img src="images/quiz.svg" alt="Tech Quiz Icon">
              </div>
              <span class="event-badge">TRIVIA</span>
            </div>
            <h3 class="event-title">Tech Quiz</h3>
            <p class="event-description">
              Multi-tiered intellectual quiz covering computing milestones, silicon architecture, operating systems, tech giants, and buzzer rounds.
            </p>
            <div class="event-specs-list">
              <div class="event-spec-row">
                <span class="spec-key"><i class="fa-solid fa-users"></i> Team:</span>
                <span class="spec-val">2 Members</span>
              </div>
              <div class="event-spec-row">
                <span class="spec-key"><i class="fa-solid fa-medal"></i> Cash Prize:</span>
                <span class="spec-val prize">₹12,000</span>
              </div>
              <div class="event-spec-row">
                <span class="spec-key"><i class="fa-solid fa-clock"></i> Date & Venue:</span>
                <span class="spec-val">26 Dec 2026 • Mini Auditorium</span>
              </div>
            </div>
            <div class="event-card-actions">
              <button type="button" class="btn btn-secondary btn-sm btn-quick-register" data-event="Tech Quiz">
                <i class="fa-solid fa-plus"></i> Select Event
              </button>
            </div>
          </article>

          <!-- Event 6: Project Expo -->
          <article class="event-card glass-card">
            <div class="event-card-header">
              <div class="event-icon-box">
                <img src="images/project-expo.svg" alt="Project Expo Icon">
              </div>
              <span class="event-badge">INNOVATION</span>
            </div>
            <h3 class="event-title">Project Expo</h3>
            <p class="event-description">
              Demonstrate functioning hardware, IoT devices, or industrial software prototypes to an esteemed panel of venture capitalists and industry founders.
            </p>
            <div class="event-specs-list">
              <div class="event-spec-row">
                <span class="spec-key"><i class="fa-solid fa-users"></i> Team:</span>
                <span class="spec-val">2 - 4 Members</span>
              </div>
              <div class="event-spec-row">
                <span class="spec-key"><i class="fa-solid fa-medal"></i> Cash Prize:</span>
                <span class="spec-val prize">₹35,000</span>
              </div>
              <div class="event-spec-row">
                <span class="spec-key"><i class="fa-solid fa-clock"></i> Date & Venue:</span>
                <span class="spec-val">28 Dec 2026 • Main Exhibition Ground</span>
              </div>
            </div>
            <div class="event-card-actions">
              <button type="button" class="btn btn-secondary btn-sm btn-quick-register" data-event="Project Expo">
                <i class="fa-solid fa-plus"></i> Select Event
              </button>
            </div>
          </article>
        </div>
      </div>
    </section>


    <!-- ========================================================
         SECTION 3: BEYOND TECHNOLOGY – NON-TECHNICAL EVENTS
         10 Brand New Non-Technical Events with Custom Cards & Badges
         ======================================================== -->
    <section class="section nontech-section" id="non-tech-events" style="background: rgba(11, 14, 28, 0.4);">
      <div class="container">
        <div class="section-header">
          <span class="section-tag nontech-tag"><i class="fa-solid fa-palette"></i> Cultural & Lifestyle</span>
          <h2 class="section-title">BEYOND TECHNOLOGY – <span class="gradient-text-pink">NON-TECHNICAL EVENTS</span></h2>
          <p class="section-subtitle">Ten premier creative, theatrical, and competitive non-technical championships designed to celebrate artistic flair, wit, stage charisma, and imagination.</p>
        </div>

        <div class="events-grid">
          <!-- Non-Tech 1: Photography Challenge -->
          <article class="event-card nontech-card glass-card">
            <div class="event-card-header">
              <div class="event-icon-box nontech-icon-box">
                <img src="images/photography.svg" alt="Photography Challenge Icon">
              </div>
              <span class="event-badge nontech-badge">CREATIVE</span>
            </div>
            <h3 class="event-title">Photography Challenge</h3>
            <p class="event-description">
              Capture campus life and cyber aesthetic through your lens. Live on-campus photo sprint with instant judging on composition, lighting, and storytelling.
            </p>
            <div class="event-specs-list">
              <div class="event-spec-row">
                <span class="spec-key"><i class="fa-solid fa-camera"></i> Mode:</span>
                <span class="spec-val">Solo Participation</span>
              </div>
              <div class="event-spec-row">
                <span class="spec-key"><i class="fa-solid fa-medal"></i> Cash Prize:</span>
                <span class="spec-val prize nontech-prize">₹10,000</span>
              </div>
              <div class="event-spec-row">
                <span class="spec-key"><i class="fa-solid fa-clock"></i> Date & Venue:</span>
                <span class="spec-val">26 Dec 2026 • Campus Wide</span>
              </div>
            </div>
            <div class="event-card-actions">
              <button type="button" class="btn btn-nontech btn-sm btn-quick-register" data-event="Photography Challenge">
                <i class="fa-solid fa-plus"></i> Select Event
              </button>
            </div>
          </article>

          <!-- Non-Tech 2: Treasure Hunt -->
          <article class="event-card nontech-card glass-card">
            <div class="event-card-header">
              <div class="event-icon-box nontech-icon-box">
                <img src="images/treasure-hunt.svg" alt="Treasure Hunt Icon">
              </div>
              <span class="event-badge nontech-badge">ADVENTURE</span>
            </div>
            <h3 class="event-title">Treasure Hunt</h3>
            <p class="event-description">
              Decrypt cyber clues, navigate cryptic riddles, and sprint across multi-tiered campus checkpoints to unlock the grand Technovate mystery vault.
            </p>
            <div class="event-specs-list">
              <div class="event-spec-row">
                <span class="spec-key"><i class="fa-solid fa-compass"></i> Team:</span>
                <span class="spec-val">2 - 4 Members</span>
              </div>
              <div class="event-spec-row">
                <span class="spec-key"><i class="fa-solid fa-medal"></i> Cash Prize:</span>
                <span class="spec-val prize nontech-prize">₹15,000</span>
              </div>
              <div class="event-spec-row">
                <span class="spec-key"><i class="fa-solid fa-clock"></i> Date & Venue:</span>
                <span class="spec-val">27 Dec 2026 • Tech Quadrangle</span>
              </div>
            </div>
            <div class="event-card-actions">
              <button type="button" class="btn btn-nontech btn-sm btn-quick-register" data-event="Treasure Hunt">
                <i class="fa-solid fa-plus"></i> Select Event
              </button>
            </div>
          </article>

          <!-- Non-Tech 3: Quiz & Trivia -->
          <article class="event-card nontech-card glass-card">
            <div class="event-card-header">
              <div class="event-icon-box nontech-icon-box">
                <img src="images/quiz-trivia.svg" alt="Quiz & Trivia Icon">
              </div>
              <span class="event-badge nontech-badge">TRIVIA</span>
            </div>
            <h3 class="event-title">Quiz & Trivia</h3>
            <p class="event-description">
              Battle of minds covering cinema, pop culture, sports, global history, and music trivia with lightning-fast buzzer face-offs.
            </p>
            <div class="event-specs-list">
              <div class="event-spec-row">
                <span class="spec-key"><i class="fa-solid fa-users"></i> Team:</span>
                <span class="spec-val">2 Members</span>
              </div>
              <div class="event-spec-row">
                <span class="spec-key"><i class="fa-solid fa-medal"></i> Cash Prize:</span>
                <span class="spec-val prize nontech-prize">₹10,000</span>
              </div>
              <div class="event-spec-row">
                <span class="spec-key"><i class="fa-solid fa-clock"></i> Date & Venue:</span>
                <span class="spec-val">26 Dec 2026 • Seminar Hall B</span>
              </div>
            </div>
            <div class="event-card-actions">
              <button type="button" class="btn btn-nontech btn-sm btn-quick-register" data-event="Quiz & Trivia">
                <i class="fa-solid fa-plus"></i> Select Event
              </button>
            </div>
          </article>

          <!-- Non-Tech 4: Ad-Zap Competition -->
          <article class="event-card nontech-card glass-card">
            <div class="event-card-header">
              <div class="event-icon-box nontech-icon-box">
                <img src="images/adzap.svg" alt="Ad-Zap Competition Icon">
              </div>
              <span class="event-badge nontech-badge">MARKETING</span>
            </div>
            <h3 class="event-title">Ad-Zap Competition</h3>
            <p class="event-description">
              Showcase witty marketing and spontaneous acting! Create, choreograph, and perform a hilarious TV advertisement for an eccentric product given on the spot.
            </p>
            <div class="event-specs-list">
              <div class="event-spec-row">
                <span class="spec-key"><i class="fa-solid fa-bullhorn"></i> Team:</span>
                <span class="spec-val">3 - 5 Members</span>
              </div>
              <div class="event-spec-row">
                <span class="spec-key"><i class="fa-solid fa-medal"></i> Cash Prize:</span>
                <span class="spec-val prize nontech-prize">₹12,000</span>
              </div>
              <div class="event-spec-row">
                <span class="spec-key"><i class="fa-solid fa-clock"></i> Date & Venue:</span>
                <span class="spec-val">27 Dec 2026 • Amphitheatre</span>
              </div>
            </div>
            <div class="event-card-actions">
              <button type="button" class="btn btn-nontech btn-sm btn-quick-register" data-event="Ad-Zap Competition">
                <i class="fa-solid fa-plus"></i> Select Event
              </button>
            </div>
          </article>

          <!-- Non-Tech 5: Dance Battle -->
          <article class="event-card nontech-card glass-card">
            <div class="event-card-header">
              <div class="event-icon-box nontech-icon-box">
                <img src="images/dance-battle.svg" alt="Dance Battle Icon">
              </div>
              <span class="event-badge nontech-badge">PERFORMING ARTS</span>
            </div>
            <h3 class="event-title">Dance Battle</h3>
            <p class="event-description">
              Electrifying stage battles covering hip-hop, street styles, contemporary, and freestyle beats judged by renowned industry choreographers.
            </p>
            <div class="event-specs-list">
              <div class="event-spec-row">
                <span class="spec-key"><i class="fa-solid fa-person-walking"></i> Mode:</span>
                <span class="spec-val">Solo or Crew (1 - 6)</span>
              </div>
              <div class="event-spec-row">
                <span class="spec-key"><i class="fa-solid fa-medal"></i> Cash Prize:</span>
                <span class="spec-val prize nontech-prize">₹20,000</span>
              </div>
              <div class="event-spec-row">
                <span class="spec-key"><i class="fa-solid fa-clock"></i> Date & Venue:</span>
                <span class="spec-val">28 Dec 2026 • Main Auditorium</span>
              </div>
            </div>
            <div class="event-card-actions">
              <button type="button" class="btn btn-nontech btn-sm btn-quick-register" data-event="Dance Battle">
                <i class="fa-solid fa-plus"></i> Select Event
              </button>
            </div>
          </article>

          <!-- Non-Tech 6: Singing Competition -->
          <article class="event-card nontech-card glass-card">
            <div class="event-card-header">
              <div class="event-icon-box nontech-icon-box">
                <img src="images/singing.svg" alt="Singing Competition Icon">
              </div>
              <span class="event-badge nontech-badge">MUSIC</span>
            </div>
            <h3 class="event-title">Singing Competition</h3>
            <p class="event-description">
              Vocal showdown celebrating acoustic, classical, Western, and contemporary melody. Mesmerize the audience with your vocal range and stage charm.
            </p>
            <div class="event-specs-list">
              <div class="event-spec-row">
                <span class="spec-key"><i class="fa-solid fa-microphone-lines"></i> Mode:</span>
                <span class="spec-val">Solo or Duo</span>
              </div>
              <div class="event-spec-row">
                <span class="spec-key"><i class="fa-solid fa-medal"></i> Cash Prize:</span>
                <span class="spec-val prize nontech-prize">₹12,000</span>
              </div>
              <div class="event-spec-row">
                <span class="spec-key"><i class="fa-solid fa-clock"></i> Date & Venue:</span>
                <span class="spec-val">27 Dec 2026 • Music Arena</span>
              </div>
            </div>
            <div class="event-card-actions">
              <button type="button" class="btn btn-nontech btn-sm btn-quick-register" data-event="Singing Competition">
                <i class="fa-solid fa-plus"></i> Select Event
              </button>
            </div>
          </article>

          <!-- Non-Tech 7: Short Film Making -->
          <article class="event-card nontech-card glass-card">
            <div class="event-card-header">
              <div class="event-icon-box nontech-icon-box">
                <img src="images/short-film.svg" alt="Short Film Making Icon">
              </div>
              <span class="event-badge nontech-badge">FILM</span>
            </div>
            <h3 class="event-title">Short Film Making</h3>
            <p class="event-description">
              Screen your cinematic masterpiece (max 10 mins). Evaluated by film directors on screenplay, acting, cinematography, audio mixing, and storytelling.
            </p>
            <div class="event-specs-list">
              <div class="event-spec-row">
                <span class="spec-key"><i class="fa-solid fa-clapperboard"></i> Team:</span>
                <span class="spec-val">2 - 5 Members</span>
              </div>
              <div class="event-spec-row">
                <span class="spec-key"><i class="fa-solid fa-medal"></i> Cash Prize:</span>
                <span class="spec-val prize nontech-prize">₹18,000</span>
              </div>
              <div class="event-spec-row">
                <span class="spec-key"><i class="fa-solid fa-clock"></i> Date & Venue:</span>
                <span class="spec-val">28 Dec 2026 • Media Theatre</span>
              </div>
            </div>
            <div class="event-card-actions">
              <button type="button" class="btn btn-nontech btn-sm btn-quick-register" data-event="Short Film Making">
                <i class="fa-solid fa-plus"></i> Select Event
              </button>
            </div>
          </article>

          <!-- Non-Tech 8: Meme Creation -->
          <article class="event-card nontech-card glass-card">
            <div class="event-card-header">
              <div class="event-icon-box nontech-icon-box">
                <img src="images/meme.svg" alt="Meme Creation Icon">
              </div>
              <span class="event-badge nontech-badge">DIGITAL HUMOR</span>
            </div>
            <h3 class="event-title">Meme Creation</h3>
            <p class="event-description">
              Unleash top-tier internet humor! Create viral, hilarious, and relatable memes based on engineering life, modern AI trends, and pop culture topics.
            </p>
            <div class="event-specs-list">
              <div class="event-spec-row">
                <span class="spec-key"><i class="fa-regular fa-face-laugh-squint"></i> Mode:</span>
                <span class="spec-val">Solo Participation</span>
              </div>
              <div class="event-spec-row">
                <span class="spec-key"><i class="fa-solid fa-medal"></i> Cash Prize:</span>
                <span class="spec-val prize nontech-prize">₹8,000</span>
              </div>
              <div class="event-spec-row">
                <span class="spec-key"><i class="fa-solid fa-clock"></i> Date & Venue:</span>
                <span class="spec-val">26 Dec 2026 • Digital Lab</span>
              </div>
            </div>
            <div class="event-card-actions">
              <button type="button" class="btn btn-nontech btn-sm btn-quick-register" data-event="Meme Creation">
                <i class="fa-solid fa-plus"></i> Select Event
              </button>
            </div>
          </article>

          <!-- Non-Tech 9: Fashion Walk -->
          <article class="event-card nontech-card glass-card">
            <div class="event-card-header">
              <div class="event-icon-box nontech-icon-box">
                <img src="images/fashion-walk.svg" alt="Fashion Walk Icon">
              </div>
              <span class="event-badge nontech-badge">LIFESTYLE</span>
            </div>
            <h3 class="event-title">Fashion Walk</h3>
            <p class="event-description">
              Walk the runway under the theme 'Cyberpunk Haute Couture & Sustainability'. Judged on poise, garments, choreography, and dramatic stage presence.
            </p>
            <div class="event-specs-list">
              <div class="event-spec-row">
                <span class="spec-key"><i class="fa-solid fa-vest"></i> Team:</span>
                <span class="spec-val">6 - 10 Members</span>
              </div>
              <div class="event-spec-row">
                <span class="spec-key"><i class="fa-solid fa-medal"></i> Cash Prize:</span>
                <span class="spec-val prize nontech-prize">₹25,000</span>
              </div>
              <div class="event-spec-row">
                <span class="spec-key"><i class="fa-solid fa-clock"></i> Date & Venue:</span>
                <span class="spec-val">28 Dec 2026 • Main Stage Ramp</span>
              </div>
            </div>
            <div class="event-card-actions">
              <button type="button" class="btn btn-nontech btn-sm btn-quick-register" data-event="Fashion Walk">
                <i class="fa-solid fa-plus"></i> Select Event
              </button>
            </div>
          </article>

          <!-- Non-Tech 10: Minute to Win It -->
          <article class="event-card nontech-card glass-card">
            <div class="event-card-header">
              <div class="event-icon-box nontech-icon-box">
                <img src="images/minute-to-win.svg" alt="Minute to Win It Icon">
              </div>
              <span class="event-badge nontech-badge">FUN & GAMES</span>
            </div>
            <h3 class="event-title">Minute to Win It</h3>
            <p class="event-description">
              60 seconds on the clock! Rapid-fire dexterity, balancing, cup stacking, and reflex challenges testing focus and nerve under the countdown timer.
            </p>
            <div class="event-specs-list">
              <div class="event-spec-row">
                <span class="spec-key"><i class="fa-solid fa-stopwatch"></i> Mode:</span>
                <span class="spec-val">Solo Participation</span>
              </div>
              <div class="event-spec-row">
                <span class="spec-key"><i class="fa-solid fa-medal"></i> Cash Prize:</span>
                <span class="spec-val prize nontech-prize">₹10,000</span>
              </div>
              <div class="event-spec-row">
                <span class="spec-key"><i class="fa-solid fa-clock"></i> Date & Venue:</span>
                <span class="spec-val">27 Dec 2026 • Activity Arena</span>
              </div>
            </div>
            <div class="event-card-actions">
              <button type="button" class="btn btn-nontech btn-sm btn-quick-register" data-event="Minute to Win It">
                <i class="fa-solid fa-plus"></i> Select Event
              </button>
            </div>
          </article>
        </div>
      </div>
    </section>


    <!-- ========================================================
         SECTION E: Event Schedule (Updated to 26–28 Dec 2026)
         ======================================================== -->
    <section class="section schedule-section" id="schedule">
      <div class="container">
        <div class="section-header">
          <span class="section-tag"><i class="fa-solid fa-timeline"></i> Timeline</span>
          <h2 class="section-title">Symposium <span class="gradient-text">Schedule</span></h2>
          <p class="section-subtitle">Comprehensive 3-day schedule of technical hackathons, cultural battles, and award ceremonies (26–28 December 2026).</p>
        </div>

        <div class="schedule-controls">
          <button type="button" class="filter-tab active" data-day="all">All Days</button>
          <button type="button" class="filter-tab" data-day="day1">Day 1 (26 Dec)</button>
          <button type="button" class="filter-tab" data-day="day2">Day 2 (27 Dec)</button>
          <button type="button" class="filter-tab" data-day="day3">Day 3 (28 Dec)</button>
        </div>

        <div class="table-responsive-wrapper">
          <table class="schedule-table" aria-label="Technovate 2026 Event Schedule">
            <thead>
              <tr>
                <th>Event Name</th>
                <th>Category</th>
                <th>Date</th>
                <th>Time Slot</th>
                <th>Venue</th>
              </tr>
            </thead>
            <tbody>
              <!-- Day 1 Entries (26 December 2026) -->
              <tr data-day="day1">
                <td>
                  <div class="schedule-event-name">
                    <i class="fa-solid fa-flag-checkered cyan-text"></i> Inaugural Ceremony & Keynote Address
                  </div>
                </td>
                <td><span class="schedule-badge">General</span></td>
                <td><time datetime="2026-12-26">26 December 2026</time></td>
                <td>09:00 AM – 10:30 AM</td>
                <td>Main University Auditorium</td>
              </tr>
              <tr data-day="day1">
                <td>
                  <div class="schedule-event-name">
                    <i class="fa-solid fa-file-lines cyan-text"></i> Paper Presentation (AI & Cloud Systems)
                  </div>
                </td>
                <td><span class="schedule-badge">Research</span></td>
                <td><time datetime="2026-12-26">26 December 2026</time></td>
                <td>11:00 AM – 02:00 PM</td>
                <td>Seminar Hall A (Block 2)</td>
              </tr>
              <tr data-day="day1">
                <td>
                  <div class="schedule-event-name">
                    <i class="fa-solid fa-camera" style="color: #ec4899;"></i> Photography Challenge (On-Campus Sprint)
                  </div>
                </td>
                <td><span class="schedule-badge nontech-sched-badge">Creative</span></td>
                <td><time datetime="2026-12-26">26 December 2026</time></td>
                <td>11:30 AM – 03:30 PM</td>
                <td>Campus Wide & Photo Lab</td>
              </tr>
              <tr data-day="day1">
                <td>
                  <div class="schedule-event-name">
                    <i class="fa-solid fa-code cyan-text"></i> Coding Challenge: Prelims & Speed Round
                  </div>
                </td>
                <td><span class="schedule-badge">Algorithms</span></td>
                <td><time datetime="2026-12-26">26 December 2026</time></td>
                <td>02:30 PM – 05:00 PM</td>
                <td>Computing Lab 3 & 4</td>
              </tr>
              <tr data-day="day1">
                <td>
                  <div class="schedule-event-name">
                    <i class="fa-solid fa-brain cyan-text"></i> Tech Quiz (Buzzer Round)
                  </div>
                </td>
                <td><span class="schedule-badge">Trivia</span></td>
                <td><time datetime="2026-12-26">26 December 2026</time></td>
                <td>03:00 PM – 05:00 PM</td>
                <td>Mini Auditorium</td>
              </tr>
              <tr data-day="day1">
                <td>
                  <div class="schedule-event-name">
                    <i class="fa-regular fa-face-laugh-squint" style="color: #ec4899;"></i> Meme Creation Challenge
                  </div>
                </td>
                <td><span class="schedule-badge nontech-sched-badge">Digital Humor</span></td>
                <td><time datetime="2026-12-26">26 December 2026</time></td>
                <td>03:30 PM – 05:30 PM</td>
                <td>Digital Media Lab</td>
              </tr>

              <!-- Day 2 Entries (27 December 2026) -->
              <tr data-day="day2">
                <td>
                  <div class="schedule-event-name">
                    <i class="fa-solid fa-laptop-code cyan-text"></i> Web Development (4-Hour Hackathon)
                  </div>
                </td>
                <td><span class="schedule-badge">Full-Stack</span></td>
                <td><time datetime="2026-12-27">27 December 2026</time></td>
                <td>09:30 AM – 01:30 PM</td>
                <td>Software Lab 1 & 2</td>
              </tr>
              <tr data-day="day2">
                <td>
                  <div class="schedule-event-name">
                    <i class="fa-solid fa-compass" style="color: #ec4899;"></i> Campus Treasure Hunt
                  </div>
                </td>
                <td><span class="schedule-badge nontech-sched-badge">Adventure</span></td>
                <td><time datetime="2026-12-27">27 December 2026</time></td>
                <td>10:00 AM – 01:00 PM</td>
                <td>Tech Quadrangle & Library</td>
              </tr>
              <tr data-day="day2">
                <td>
                  <div class="schedule-event-name">
                    <i class="fa-solid fa-robot cyan-text"></i> Robotics Arena: Autonomous Line Follower
                  </div>
                </td>
                <td><span class="schedule-badge">Hardware</span></td>
                <td><time datetime="2026-12-27">27 December 2026</time></td>
                <td>10:30 AM – 01:30 PM</td>
                <td>Indoor Sports Complex</td>
              </tr>
              <tr data-day="day2">
                <td>
                  <div class="schedule-event-name">
                    <i class="fa-solid fa-bullhorn" style="color: #ec4899;"></i> Ad-Zap Competition
                  </div>
                </td>
                <td><span class="schedule-badge nontech-sched-badge">Marketing</span></td>
                <td><time datetime="2026-12-27">27 December 2026</time></td>
                <td>02:00 PM – 04:30 PM</td>
                <td>Open Air Amphitheatre</td>
              </tr>
              <tr data-day="day2">
                <td>
                  <div class="schedule-event-name">
                    <i class="fa-solid fa-microphone-lines" style="color: #ec4899;"></i> Singing Competition
                  </div>
                </td>
                <td><span class="schedule-badge nontech-sched-badge">Music</span></td>
                <td><time datetime="2026-12-27">27 December 2026</time></td>
                <td>02:30 PM – 05:00 PM</td>
                <td>Music Arena</td>
              </tr>
              <tr data-day="day2">
                <td>
                  <div class="schedule-event-name">
                    <i class="fa-solid fa-stopwatch" style="color: #ec4899;"></i> Minute to Win It Finals
                  </div>
                </td>
                <td><span class="schedule-badge nontech-sched-badge">Fun Games</span></td>
                <td><time datetime="2026-12-27">27 December 2026</time></td>
                <td>03:30 PM – 05:30 PM</td>
                <td>Activity Arena</td>
              </tr>

              <!-- Day 3 Entries (28 December 2026) -->
              <tr data-day="day3">
                <td>
                  <div class="schedule-event-name">
                    <i class="fa-solid fa-rocket cyan-text"></i> Project Expo: Public Demonstration & Judging
                  </div>
                </td>
                <td><span class="schedule-badge">Innovation</span></td>
                <td><time datetime="2026-12-28">28 December 2026</time></td>
                <td>09:30 AM – 01:00 PM</td>
                <td>Main Exhibition Ground</td>
              </tr>
              <tr data-day="day3">
                <td>
                  <div class="schedule-event-name">
                    <i class="fa-solid fa-clapperboard" style="color: #ec4899;"></i> Short Film Making Screenings
                  </div>
                </td>
                <td><span class="schedule-badge nontech-sched-badge">Cinema</span></td>
                <td><time datetime="2026-12-28">28 December 2026</time></td>
                <td>10:00 AM – 01:00 PM</td>
                <td>Media Theatre</td>
              </tr>
              <tr data-day="day3">
                <td>
                  <div class="schedule-event-name">
                    <i class="fa-solid fa-person-walking" style="color: #ec4899;"></i> Dance Battle (Solo & Crew Finals)
                  </div>
                </td>
                <td><span class="schedule-badge nontech-sched-badge">Dance</span></td>
                <td><time datetime="2026-12-28">28 December 2026</time></td>
                <td>01:30 PM – 03:30 PM</td>
                <td>Main Auditorium Stage</td>
              </tr>
              <tr data-day="day3">
                <td>
                  <div class="schedule-event-name">
                    <i class="fa-solid fa-vest" style="color: #ec4899;"></i> Fashion Walk (Cyber Couture Showcase)
                  </div>
                </td>
                <td><span class="schedule-badge nontech-sched-badge">Fashion</span></td>
                <td><time datetime="2026-12-28">28 December 2026</time></td>
                <td>03:30 PM – 05:00 PM</td>
                <td>Main Stage Ramp</td>
              </tr>
              <tr data-day="day3">
                <td>
                  <div class="schedule-event-name">
                    <i class="fa-solid fa-trophy cyan-text"></i> Grand Valedictory Ceremony & Prize Distribution
                  </div>
                </td>
                <td><span class="schedule-badge">Awards</span></td>
                <td><time datetime="2026-12-28">28 December 2026</time></td>
                <td>05:30 PM – 07:30 PM</td>
                <td>Main University Auditorium</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </section>


    <!-- ========================================================
         SECTION F: Registration Section & HTML5 Form
         Supports Both Technical & Non-Technical Event Selection
         Strict Date Constraints: 26, 27, or 28 December 2026
         ======================================================== -->
    <section class="section registration-section" id="register">
      <div class="container">
        <div class="section-header">
          <span class="section-tag"><i class="fa-solid fa-id-badge"></i> Candidate Enrollment</span>
          <h2 class="section-title">Official Portal <span class="gradient-text">Registration</span></h2>
          <p class="section-subtitle">Enroll for Technical & Non-Technical competitions. Select any participation date: 26, 27, or 28 December 2026.</p>
        </div>

        <div id="formErrorContainer"></div>

        <div class="registration-wrapper glass-card">
          <form id="registrationForm" action="register.php" method="POST" novalidate>
            <div class="reg-form-grid">
              
              <!-- 1. Student Name -->
              <div class="form-group">
                <label for="student_name" class="form-label">
                  <i class="fa-regular fa-user"></i> Student Full Name <span class="req-star">*</span>
                </label>
                <input type="text" 
                       id="student_name" 
                       name="student_name" 
                       class="form-control" 
                       placeholder="e.g. Johnathan Doe" 
                       required>
                <span class="input-error-msg"></span>
              </div>

              <!-- 2. Register Number -->
              <div class="form-group">
                <label for="reg_number" class="form-label">
                  <i class="fa-solid fa-hashtag"></i> Register / Roll Number <span class="req-star">*</span>
                </label>
                <input type="text" 
                       id="reg_number" 
                       name="reg_number" 
                       class="form-control" 
                       placeholder="e.g. 21CS1045" 
                       required>
                <span class="input-error-msg"></span>
              </div>

              <!-- 3. Email Address -->
              <div class="form-group">
                <label for="email" class="form-label">
                  <i class="fa-regular fa-envelope"></i> Email Address <span class="req-star">*</span>
                </label>
                <input type="email" 
                       id="email" 
                       name="email" 
                       class="form-control" 
                       placeholder="student@institution.edu" 
                       required>
                <span class="input-error-msg"></span>
              </div>

              <!-- 4. Mobile Number -->
              <div class="form-group">
                <label for="phone" class="form-label">
                  <i class="fa-solid fa-phone"></i> Mobile Number (10 Digits) <span class="req-star">*</span>
                </label>
                <input type="tel" 
                       id="phone" 
                       name="phone" 
                       class="form-control" 
                       placeholder="9876543210" 
                       pattern="[0-9]{10}"
                       maxlength="10"
                       required>
                <span class="input-error-msg"></span>
              </div>

              <!-- 5. College Name -->
              <div class="form-group form-group-full">
                <label for="college_name" class="form-label">
                  <i class="fa-solid fa-graduation-cap"></i> College / University Name <span class="req-star">*</span>
                </label>
                <input type="text" 
                       id="college_name" 
                       name="college_name" 
                       class="form-control" 
                       placeholder="e.g. Apex Institute of Science & Technology" 
                       required>
                <span class="input-error-msg"></span>
              </div>

              <!-- 6. Department -->
              <div class="form-group">
                <label for="department" class="form-label">
                  <i class="fa-solid fa-network-wired"></i> Department <span class="req-star">*</span>
                </label>
                <select id="department" name="department" class="form-control" required>
                  <option value="" disabled selected>-- Select Department --</option>
                  <option value="Computer Science & Engineering">Computer Science & Engineering (CSE)</option>
                  <option value="Information Technology">Information Technology (IT)</option>
                  <option value="Artificial Intelligence & Data Science">Artificial Intelligence & Data Science (AI & DS)</option>
                  <option value="Electronics & Communication">Electronics & Communication (ECE)</option>
                  <option value="Electrical & Electronics">Electrical & Electronics (EEE)</option>
                  <option value="Mechanical & Mechatronics">Mechanical & Mechatronics Engineering</option>
                  <option value="Management & Commerce">Management & Commerce</option>
                  <option value="Media & Fine Arts">Media & Fine Arts</option>
                  <option value="Other Department">Other Department</option>
                </select>
                <span class="input-error-msg"></span>
              </div>

              <!-- 7. Year of Study -->
              <div class="form-group">
                <label for="year_of_study" class="form-label">
                  <i class="fa-solid fa-calendar-check"></i> Year of Study <span class="req-star">*</span>
                </label>
                <select id="year_of_study" name="year_of_study" class="form-control" required>
                  <option value="" disabled selected>-- Select Current Year --</option>
                  <option value="1st Year">1st Year (Freshman)</option>
                  <option value="2nd Year">2nd Year (Sophomore)</option>
                  <option value="3rd Year">3rd Year (Junior)</option>
                  <option value="4th Year / Final Year">4th Year (Senior / Final Year)</option>
                  <option value="Post-Graduate / Masters">Post-Graduate / Masters</option>
                </select>
                <span class="input-error-msg"></span>
              </div>

              <!-- 8. Multi-Event Category Selection (Technical & Non-Technical) -->
              <div class="form-group form-group-full">
                <label class="form-label">
                  <i class="fa-solid fa-layer-group"></i> Select Events to Participate (Multiple Selection Allowed) <span class="req-star">*</span>
                </label>

                <!-- Technical Events Group (6 Events) -->
                <div class="event-category-group">
                  <div class="event-category-title" style="color: var(--cyan);">
                    <i class="fa-solid fa-microchip"></i> Technical Events (6 Events)
                  </div>
                  <div class="events-checkbox-grid">
                    <label class="custom-checkbox-card">
                      <input type="checkbox" name="events[]" value="Paper Presentation">
                      <span>Paper Presentation</span>
                    </label>
                    <label class="custom-checkbox-card">
                      <input type="checkbox" name="events[]" value="Coding Challenge">
                      <span>Coding Challenge</span>
                    </label>
                    <label class="custom-checkbox-card">
                      <input type="checkbox" name="events[]" value="Web Development">
                      <span>Web Development</span>
                    </label>
                    <label class="custom-checkbox-card">
                      <input type="checkbox" name="events[]" value="Robotics">
                      <span>Robotics Challenge</span>
                    </label>
                    <label class="custom-checkbox-card">
                      <input type="checkbox" name="events[]" value="Tech Quiz">
                      <span>Tech Quiz</span>
                    </label>
                    <label class="custom-checkbox-card">
                      <input type="checkbox" name="events[]" value="Project Expo">
                      <span>Project Expo</span>
                    </label>
                  </div>
                </div>

                <!-- Non-Technical Events Group (10 Events) -->
                <div class="event-category-group" style="margin-top: 16px;">
                  <div class="event-category-title" style="color: #f472b6;">
                    <i class="fa-solid fa-masks-theater"></i> Non-Technical Events (10 Events)
                  </div>
                  <div class="events-checkbox-grid">
                    <label class="custom-checkbox-card nontech-cb">
                      <input type="checkbox" name="events[]" value="Photography Challenge">
                      <span>Photography Challenge</span>
                    </label>
                    <label class="custom-checkbox-card nontech-cb">
                      <input type="checkbox" name="events[]" value="Treasure Hunt">
                      <span>Treasure Hunt</span>
                    </label>
                    <label class="custom-checkbox-card nontech-cb">
                      <input type="checkbox" name="events[]" value="Quiz & Trivia">
                      <span>Quiz & Trivia</span>
                    </label>
                    <label class="custom-checkbox-card nontech-cb">
                      <input type="checkbox" name="events[]" value="Ad-Zap Competition">
                      <span>Ad-Zap Competition</span>
                    </label>
                    <label class="custom-checkbox-card nontech-cb">
                      <input type="checkbox" name="events[]" value="Dance Battle">
                      <span>Dance Battle</span>
                    </label>
                    <label class="custom-checkbox-card nontech-cb">
                      <input type="checkbox" name="events[]" value="Singing Competition">
                      <span>Singing Competition</span>
                    </label>
                    <label class="custom-checkbox-card nontech-cb">
                      <input type="checkbox" name="events[]" value="Short Film Making">
                      <span>Short Film Making</span>
                    </label>
                    <label class="custom-checkbox-card nontech-cb">
                      <input type="checkbox" name="events[]" value="Meme Creation">
                      <span>Meme Creation</span>
                    </label>
                    <label class="custom-checkbox-card nontech-cb">
                      <input type="checkbox" name="events[]" value="Fashion Walk">
                      <span>Fashion Walk</span>
                    </label>
                    <label class="custom-checkbox-card nontech-cb">
                      <input type="checkbox" name="events[]" value="Minute to Win It">
                      <span>Minute to Win It</span>
                    </label>
                  </div>
                </div>

                <span class="input-error-msg" id="eventsErrorMsg"></span>
              </div>

              <!-- 9. Participation Date (Strict Range: 26, 27, or 28 December 2026) -->
              <div class="form-group">
                <label for="participation_date" class="form-label">
                  <i class="fa-regular fa-calendar-check"></i> Participation Date (26, 27, or 28 Dec 2026) <span class="req-star">*</span>
                </label>
                <input type="date" 
                       id="participation_date" 
                       name="participation_date" 
                       class="form-control" 
                       min="2026-12-26" 
                       max="2026-12-28" 
                       value="2026-12-26"
                       required>
                <small style="color: var(--text-muted); font-size: 0.8rem; margin-top: 2px;">
                  Symposium dates: 26, 27, or 28 December 2026.
                </small>
                <span class="input-error-msg"></span>
              </div>

              <!-- 10. Gender -->
              <div class="form-group">
                <label class="form-label">
                  <i class="fa-solid fa-venus-mars"></i> Gender <span class="req-star">*</span>
                </label>
                <div class="gender-radio-group">
                  <label class="custom-radio-label">
                    <input type="radio" name="gender" value="Male" required>
                    <span>Male</span>
                  </label>
                  <label class="custom-radio-label">
                    <input type="radio" name="gender" value="Female">
                    <span>Female</span>
                  </label>
                  <label class="custom-radio-label">
                    <input type="radio" name="gender" value="Other">
                    <span>Other</span>
                  </label>
                </div>
                <span class="input-error-msg" id="genderErrorMsg"></span>
              </div>

              <!-- 11. Additional Message -->
              <div class="form-group form-group-full">
                <label for="message" class="form-label">
                  <i class="fa-regular fa-comment-dots"></i> Additional Message / Specific Requirements (Optional)
                </label>
                <textarea id="message" 
                          name="message" 
                          class="form-control" 
                          rows="3" 
                          placeholder="Provide hardware requirements, music tracks for dance, or dietary accommodations..."></textarea>
              </div>

              <!-- 12. Terms & Conditions -->
              <div class="form-group form-group-full">
                <div class="terms-agreement">
                  <input type="checkbox" id="terms" name="terms" value="1" required>
                  <label for="terms">
                    I declare that all details provided are true and accurate. I agree to abide by the official rules, ethical code of conduct, and guidelines of <strong>TECHNOVATE 2026 (26–28 December 2026)</strong>.
                  </label>
                </div>
                <span class="input-error-msg" id="termsErrorMsg"></span>
              </div>

              <!-- 13. Form Action Buttons -->
              <div class="form-group-full form-buttons-row">
                <button type="reset" class="btn btn-reset">
                  <i class="fa-solid fa-rotate-left"></i> Reset Form
                </button>
                <button type="submit" class="btn btn-primary">
                  <i class="fa-solid fa-paper-plane"></i> Submit Registration
                </button>
              </div>

            </div>
          </form>
        </div>
      </div>
    </section>


    <!-- ========================================================
         SECTION G: Contact Section
         ======================================================== -->
    <section class="section contact-section" id="contact">
      <div class="container">
        <div class="section-header">
          <span class="section-tag"><i class="fa-solid fa-headset"></i> Connect With Us</span>
          <h2 class="section-title">Get In <span class="gradient-text">Touch</span></h2>
          <p class="section-subtitle">Reach out for accommodation, event rules, and transportation assistance for TECHNOVATE 2026.</p>
        </div>

        <div class="contact-grid">
          <div class="contact-card glass-card">
            <h3>Symposium Headquarters</h3>
            <p style="color: var(--text-muted); margin-top: 6px;">Feel free to drop by our department office or reach out via email.</p>

            <div class="contact-info-list">
              <div class="contact-item">
                <div class="contact-icon-box"><i class="fa-solid fa-map-location-dot"></i></div>
                <div class="contact-details">
                  <h4>College Location</h4>
                  <p>National Apex Institute of Technology<br>Innovation Highway, Tech Knowledge City, Metro Hub - 600028</p>
                </div>
              </div>

              <div class="contact-item">
                <div class="contact-icon-box"><i class="fa-regular fa-envelope"></i></div>
                <div class="contact-details">
                  <h4>Official Email</h4>
                  <p><a href="mailto:technovate2026@apex.edu" style="color: var(--cyan);">technovate2026@apex.edu</a></p>
                </div>
              </div>

              <div class="contact-item">
                <div class="contact-icon-box"><i class="fa-solid fa-phone-volume"></i></div>
                <div class="contact-details">
                  <h4>Helpline Numbers</h4>
                  <p>+91 (044) 2890-4100 / +91 98401 23456</p>
                </div>
              </div>
            </div>

            <div class="social-icons-row">
              <a href="#" class="social-btn" aria-label="GitHub"><i class="fa-brands fa-github"></i></a>
              <a href="#" class="social-btn" aria-label="LinkedIn"><i class="fa-brands fa-linkedin-in"></i></a>
              <a href="#" class="social-btn" aria-label="Instagram"><i class="fa-brands fa-instagram"></i></a>
              <a href="#" class="social-btn" aria-label="Discord"><i class="fa-brands fa-discord"></i></a>
              <a href="#" class="social-btn" aria-label="YouTube"><i class="fa-brands fa-youtube"></i></a>
              <a href="#" class="social-btn" aria-label="Twitter"><i class="fa-brands fa-x-twitter"></i></a>
            </div>
          </div>

          <div class="coordinators-card glass-card">
            <h3>Event Coordinators</h3>
            <p style="color: var(--text-muted); margin-top: 6px;">Direct contacts for event-specific queries and technical clarifications.</p>

            <div class="coordinator-list">
              <div class="coord-profile">
                <div class="coord-avatar">DR</div>
                <div class="coord-info">
                  <h5>Dr. Rajesh Kumar, Ph.D.</h5>
                  <span>Faculty Convenor • Dept. of CSE</span>
                  <p style="font-size: 0.82rem; color: var(--text-muted); margin-top: 2px;">Email: rajesh.kumar@apex.edu</p>
                </div>
              </div>

              <div class="coord-profile">
                <div class="coord-avatar">SK</div>
                <div class="coord-info">
                  <h5>Siddharth K. & Ananya Roy</h5>
                  <span>Overall Student Chairpersons</span>
                  <p style="font-size: 0.82rem; color: var(--text-muted); margin-top: 2px;">Mobile: +91 97910 88231 / +91 94440 19283</p>
                </div>
              </div>

              <div class="coord-profile">
                <div class="coord-avatar">TR</div>
                <div class="coord-info">
                  <h5>Technical Support Desk</h5>
                  <span>Portal & Registration Desk</span>
                  <p style="font-size: 0.82rem; color: var(--text-muted); margin-top: 2px;">Tech Queries: support.technovate@apex.edu</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main>


  <!-- ========================================================
       SECTION H: Footer
       Dates Updated: 26–28 December 2026
       ======================================================== -->
  <footer class="site-footer">
    <div class="container">
      <div class="footer-grid">
        <div class="footer-col">
          <img src="images/logo.svg" alt="TECHNOVATE 2026 Logo" style="height: 38px; margin-bottom: 18px;">
          <p style="color: var(--text-muted); font-size: 0.92rem; line-height: 1.7; max-width: 320px;">
            TECHNOVATE 2026 (26–28 December 2026) is the national festival celebrating engineering excellence, algorithmic breakthroughs, and cultural expression.
          </p>
        </div>

        <div class="footer-col">
          <h4>Quick Navigation</h4>
          <ul class="footer-links-list">
            <li><a href="#home" class="footer-link">Home</a></li>
            <li><a href="#about" class="footer-link">About Fest</a></li>
            <li><a href="#events" class="footer-link">Technical Events</a></li>
            <li><a href="#non-tech-events" class="footer-link">Non-Technical</a></li>
            <li><a href="#schedule" class="footer-link">Schedule (26–28 Dec)</a></li>
            <li><a href="#register" class="footer-link">Register Online</a></li>
          </ul>
        </div>

        <div class="footer-col">
          <h4>Event Categories</h4>
          <ul class="footer-links-list">
            <li><a href="#events" class="footer-link">Coding & Algorithms</a></li>
            <li><a href="#events" class="footer-link">Robotics Battleground</a></li>
            <li><a href="#non-tech-events" class="footer-link">Dance & Music Battles</a></li>
            <li><a href="#non-tech-events" class="footer-link">Photography & Film</a></li>
            <li><a href="#non-tech-events" class="footer-link">Treasure Hunt & Ad-Zap</a></li>
            <li><a href="#non-tech-events" class="footer-link">Fashion Walk</a></li>
          </ul>
        </div>

        <div class="footer-col">
          <h4>Symposium Highlights</h4>
          <p style="color: var(--text-muted); font-size: 0.9rem; margin-bottom: 14px;">
            Dates: <strong>26–28 December 2026</strong>. Verified digital admission pass provided to every confirmed student.
          </p>
          <div style="font-family: var(--font-mono); font-size: 0.8rem; color: var(--cyan);">
            <i class="fa-solid fa-shield-check"></i> ISO 9001:2015 Certified Symposium
          </div>
        </div>
      </div>

      <div class="footer-bottom-bar">
        <div>
          © 2026 TECHNOVATE • Department of Computer Science & Engineering, Apex Institute of Technology. All Rights Reserved.
        </div>
        <div style="display: flex; gap: 20px;">
          <a href="#terms" class="footer-link">Rules & Regulations</a>
          <a href="#contact" class="footer-link">Code of Conduct</a>
          <a href="#contact" class="footer-link">Privacy Policy</a>
        </div>
      </div>
    </div>
  </footer>


  <!-- Back to Top Floating Button -->
  <button id="backToTop" class="back-to-top" aria-label="Back to Top">
    <i class="fa-solid fa-arrow-up"></i>
  </button>


  <!-- ========================================================
       SECTION 5 & 6: REGISTRATION SUCCESS MODAL & DIGITAL PASS
       Contains: Success message, Student name, Registration ID,
       Selected events, Participation date, and TWO SEPARATE BUTTONS:
       1. PRINT EVENT PASS (Prints ONLY the pass via @media print)
       2. REGISTER ANOTHER STUDENT (Returns to clean form)
       ======================================================== -->
  <div class="modal-overlay" id="confirmationModal" role="dialog" aria-modal="true" aria-labelledby="modalTitle">
    <div class="success-modal-content">
      
      <!-- Modal Header (Screen Only) -->
      <div class="success-header-banner no-print">
        <div class="success-icon-badge">
          <div class="success-checkmark">
            <i class="fa-solid fa-check"></i>
          </div>
          <div>
            <h3 id="modalTitle" style="color: #ffffff; font-size: 1.35rem;">Congratulations! Your registration is confirmed.</h3>
            <p style="color: var(--text-secondary); font-size: 0.88rem;">Welcome to TECHNOVATE 2026 (26–28 December 2026).</p>
          </div>
        </div>
        <button type="button" class="modal-close-btn" id="closeModalBtn" aria-label="Close modal">
          <i class="fa-solid fa-xmark"></i>
        </button>
      </div>

      <div class="success-modal-body">
        
        <!-- Summary Strip (Screen Only) -->
        <div class="glass-card no-print" style="padding: 16px 20px; margin-bottom: 20px; background: rgba(15, 23, 42, 0.7); border-color: rgba(0, 240, 255, 0.3);">
          <div style="display: flex; flex-wrap: wrap; justify-content: space-between; gap: 12px; align-items: center;">
            <div>
              <span style="font-size: 0.75rem; color: var(--text-muted); text-transform: uppercase;">Candidate Name</span>
              <div id="successStudentName" style="font-size: 1.15rem; font-weight: 700; color: #ffffff;">-</div>
            </div>
            <div>
              <span style="font-size: 0.75rem; color: var(--text-muted); text-transform: uppercase;">Registration ID</span>
              <div id="successRegId" style="font-family: var(--font-mono); font-size: 1.25rem; font-weight: 900; color: var(--cyan); letter-spacing: 1px;">TEC2026-0001</div>
            </div>
            <div>
              <span style="font-size: 0.75rem; color: var(--text-muted); text-transform: uppercase;">Participation Date</span>
              <div id="successDate" style="font-size: 0.95rem; font-weight: 700; color: #38bdf8;">26 December 2026</div>
            </div>
          </div>
          <div style="margin-top: 10px; padding-top: 10px; border-top: 1px solid rgba(255,255,255,0.06);">
            <span style="font-size: 0.75rem; color: var(--text-muted); text-transform: uppercase; display: block; margin-bottom: 4px;">Registered Events:</span>
            <div id="successEventsList"></div>
          </div>
        </div>

        <!-- ========================================================
             THE OFFICIAL PRINTABLE DIGITAL ENTRY PASS CONTAINER
             This container is explicitly isolated by @media print.
             In print preview, ONLY this pass appears on a clean page.
             ======================================================== -->
        <div id="printablePassContainer">
          <div class="official-digital-pass">
            
            <!-- Pass Header -->
            <div class="pass-header">
              <div class="pass-brand">
                <img src="images/logo.svg" alt="TECHNOVATE 2026 Logo">
                <div class="pass-symposium-info">
                  <h3>TECHNOVATE 2026</h3>
                  <p>National Technical & Cultural Symposium • Apex Institute of Technology</p>
                </div>
              </div>
              <div class="pass-auth-badge">
                <span class="pass-auth-tag">AUTHORIZED ENTRY PASS</span>
                <div class="pass-dates-sub">26–28 December 2026</div>
              </div>
            </div>

            <!-- Prominent Persistent Registration ID Strip -->
            <div class="pass-id-banner">
              <div>
                <span class="id-lbl">Official Registration ID</span>
                <div class="id-val" id="passRegId">TEC2026-0001</div>
              </div>
              <div style="text-align: right;">
                <span class="id-lbl">Status</span>
                <div>
                  <span class="pass-status-confirmed">CONFIRMED</span>
                </div>
              </div>
            </div>

            <!-- Two-Column Student Information Grid -->
            <div class="pass-details-2col">
              <!-- Left Column: Student Details -->
              <div class="pass-col">
                <div class="pass-detail-item">
                  <span class="pass-detail-label">Student Name:</span>
                  <span class="pass-detail-value" id="passStudentName">-</span>
                </div>
                <div class="pass-detail-item">
                  <span class="pass-detail-label">Register / Roll Number:</span>
                  <span class="pass-detail-value" id="passRegNo">-</span>
                </div>
                <div class="pass-detail-item">
                  <span class="pass-detail-label">College / University:</span>
                  <span class="pass-detail-value" id="passCollege">-</span>
                </div>
                <div class="pass-detail-item">
                  <span class="pass-detail-label">Department & Year of Study:</span>
                  <span class="pass-detail-value" id="passDept">-</span>
                </div>
              </div>

              <!-- Right Column: Event & Date Details -->
              <div class="pass-col">
                <div class="pass-detail-item">
                  <span class="pass-detail-label">Scheduled Participation Date:</span>
                  <span class="pass-detail-value" id="passDate" style="color: #6d28d9;">26 December 2026</span>
                </div>
                <div class="pass-detail-item">
                  <span class="pass-detail-label">Registered Events (Technical & Non-Technical):</span>
                  <div class="pass-events-box" id="passEvents">• Event Name</div>
                </div>
              </div>
            </div>

            <!-- Pass Footer Strip -->
            <div class="pass-footer-strip">
              <div class="pass-qr-group">
                <img src="images/qr-sample.svg" alt="Registration Verification QR Code" class="pass-qr-code-img" id="passQrImg">
                <div class="pass-terms-note">
                  <strong>Verification Instructions:</strong> Present this printed or digital pass at the entrance gate along with a valid College Identity Card. Admittance subject to symposium security protocols.
                </div>
              </div>
              <div class="pass-signature-stamp">
                <div class="stamp-title">Convenor, TECHNOVATE 2026</div>
                <div style="font-size: 0.75rem; color: #64748b;">Department of Computer Science & Engineering</div>
                <div class="stamp-verified"><i class="fa-solid fa-circle-check"></i> DIGITALLY VERIFIED CREDENTIAL</div>
              </div>
            </div>

          </div>
        </div>

        <!-- ========================================================
             TWO SEPARATE ACTION BUTTONS (Outside the printable pass)
             1. PRINT EVENT PASS
             2. REGISTER ANOTHER STUDENT
             ======================================================== -->
        <div class="success-actions-row no-print">
          <button type="button" class="btn btn-secondary" id="registerAnotherBtn">
            <i class="fa-solid fa-user-plus"></i> REGISTER ANOTHER STUDENT
          </button>
          <button type="button" class="btn btn-primary" id="printPassBtn">
            <i class="fa-solid fa-print"></i> PRINT EVENT PASS
          </button>
        </div>

      </div>
    </div>
  </div>


  <!-- REQUIREMENT 6 (JavaScript): External Script File -->
  <script src="script.js"></script>
</body>
</html>
