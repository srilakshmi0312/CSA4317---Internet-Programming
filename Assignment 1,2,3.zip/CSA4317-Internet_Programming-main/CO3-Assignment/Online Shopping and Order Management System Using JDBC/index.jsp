<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.shopzone.model.Customer, com.shopzone.model.Cart, com.shopzone.model.Product, com.shopzone.dao.ProductDAO, java.util.List" %>
<%
    // Session state retrieval
    Customer customer = (Customer) session.getAttribute("customer");
    Cart cart = (Cart) session.getAttribute("cart");
    int cartCount = (cart != null) ? cart.getTotalItemCount() : 0;

    // Fetch featured products from database for the home page
    ProductDAO productDAO = new ProductDAO();
    List<Product> featuredProducts = productDAO.getFeaturedProducts(6);
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SHOPZONE - Everything You Need, All in One Place</title>
    <!-- Stylesheets -->
    <link rel="stylesheet" href="css/style.css">
    <!-- Google Fonts for Modern Typography -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Plus Jakarta Sans', var(--font-family); }
    </style>
</head>
<body>

<div class="app-wrapper">
    <!-- Mobile Sidebar Backdrop Overlay -->
    <div class="sidebar-overlay"></div>

    <!-- ==========================================
         1. VERTICAL SIDEBAR NAVIGATION
         ========================================== -->
    <aside class="app-sidebar">
        <!-- Brand Header -->
        <div class="sidebar-header">
            <a href="index.jsp" class="brand-link">
                <div class="brand-icon-box">🛍️</div>
                <div class="brand-info">
                    <span class="brand-name">SHOP<span>ZONE</span></span>
                    <span class="brand-tagline">Everything You Need</span>
                </div>
            </a>
        </div>

        <!-- Vertical Navigation Menu -->
        <nav class="sidebar-nav">
            <span class="nav-section-title">Menu</span>
            <a href="index.jsp" class="nav-item active">
                <span class="nav-icon">🏠</span>
                <span>Home</span>
            </a>
            <a href="products" class="nav-item">
                <span class="nav-icon">✨</span>
                <span>Browse Products</span>
            </a>
            <a href="cart.jsp" class="nav-item">
                <span class="nav-icon">🛒</span>
                <span>Shopping Cart</span>
                <span class="nav-badge"><%= cartCount %></span>
            </a>
            <a href="my-orders" class="nav-item">
                <span class="nav-icon">📦</span>
                <span>My Orders</span>
            </a>

            <span class="nav-section-title">Categories</span>
            <a href="products?category=Electronics" class="nav-item">
                <span class="nav-icon">⚡</span>
                <span>Electronics</span>
            </a>
            <a href="products?category=Fashion" class="nav-item">
                <span class="nav-icon">👗</span>
                <span>Fashion</span>
            </a>
            <a href="products?category=Home+Appliances" class="nav-item">
                <span class="nav-icon">🏠</span>
                <span>Home Appliances</span>
            </a>
            <a href="products?category=Books" class="nav-item">
                <span class="nav-icon">📚</span>
                <span>Books</span>
            </a>
            <a href="products?category=Accessories" class="nav-item">
                <span class="nav-icon">🎒</span>
                <span>Accessories</span>
            </a>
        </nav>

        <!-- Sidebar Customer Account Footer -->
        <div class="sidebar-footer">
            <% if (customer != null) { %>
                <div class="customer-card">
                    <div class="customer-avatar">
                        <%= customer.getCustomerName().substring(0, 1).toUpperCase() %>
                    </div>
                    <div class="customer-meta">
                        <div class="name"><%= customer.getCustomerName() %></div>
                        <span class="id-badge"><%= customer.getCustomerId() %></span>
                    </div>
                    <a href="logout" class="btn-logout" title="Log Out">🚪</a>
                </div>
            <% } else { %>
                <div class="auth-button-group">
                    <a href="login.jsp" class="btn btn-secondary btn-sm">Login</a>
                    <a href="register.jsp" class="btn btn-primary btn-sm">Register</a>
                </div>
            <% } %>
        </div>
    </aside>

    <!-- ==========================================
         2. MAIN CONTENT AREA
         ========================================== -->
    <main class="app-main">
        <!-- Top Action Header -->
        <header class="top-header">
            <button class="mobile-menu-toggle" aria-label="Toggle Sidebar Menu">☰</button>

            <!-- Product Search Form (Submits to ProductServlet using GET) -->
            <form action="products" method="GET" class="header-search-form">
                <select name="category" class="search-category-select">
                    <option value="All">All Categories</option>
                    <option value="Electronics">Electronics</option>
                    <option value="Fashion">Fashion</option>
                    <option value="Home Appliances">Home Appliances</option>
                    <option value="Books">Books</option>
                    <option value="Accessories">Accessories</option>
                </select>
                <input type="text" name="search" class="search-input" placeholder="Search products, brands and more..." required>
                <button type="submit" class="search-submit-btn" title="Search Products">🔍</button>
            </form>

            <!-- Quick Actions -->
            <div class="header-actions">
                <a href="cart.jsp" class="header-cart-btn" title="View Shopping Cart">
                    <span class="header-cart-icon">🛒</span>
                    <span>Cart</span>
                    <span class="header-cart-count"><%= cartCount %></span>
                </a>
            </div>
        </header>

        <!-- Content Canvas -->
        <div class="content-canvas">
            
            <!-- Welcome Alert Notification -->
            <% if (customer != null) { %>
                <div class="alert alert-info">
                    <span>👋 Welcome back, <strong><%= customer.getCustomerName() %></strong>! Ready to discover the latest tech and lifestyle deals?</span>
                </div>
            <% } %>

            <!-- Feedback Toasts -->
            <% 
                String cartSuccess = (String) session.getAttribute("cartSuccess");
                String cartError = (String) session.getAttribute("cartError");
                if (cartSuccess != null) { 
                    session.removeAttribute("cartSuccess");
            %>
                <div class="alert alert-success">✅ <%= cartSuccess %></div>
            <% } %>
            <% if (cartError != null) { 
                    session.removeAttribute("cartError");
            %>
                <div class="alert alert-error">⚠️ <%= cartError %></div>
            <% } %>

            <!-- Hero Welcome Banner -->
            <section class="hero-banner">
                <div class="hero-content">
                    <div class="hero-badge">✨ Official Store</div>
                    <h1 class="hero-title">Welcome to <span>SHOPZONE</span></h1>
                    <p class="hero-subtitle">
                        Everything You Need, All in One Place. Explore our premium selection of electronics, modern fashion, home essentials, best-selling books, and everyday accessories at unbeatable prices.
                    </p>
                    <div class="hero-actions">
                        <a href="products" class="btn btn-primary btn-lg">Explore Catalog →</a>
                        <a href="products?category=Electronics" class="btn btn-secondary btn-lg">Shop Electronics</a>
                    </div>
                </div>
                <div class="hero-illustration">
                    <img src="images/products/smartwatch.svg" alt="Featured Tech" style="max-height: 180px;">
                </div>
            </section>

            <!-- Category Quick Tiles -->
            <div class="section-header">
                <div class="section-title-wrap">
                    <h2>Explore Categories</h2>
                    <p>Find exactly what you're looking for organized by collection</p>
                </div>
                <a href="products" class="btn btn-lavender btn-sm">View All Categories →</a>
            </div>

            <div class="category-grid">
                <a href="products?category=Electronics" class="category-card">
                    <div class="category-icon-box">⚡</div>
                    <div class="category-details">
                        <h4>Electronics</h4>
                        <span>Audio, Wearables, Laptops</span>
                    </div>
                </a>
                <a href="products?category=Fashion" class="category-card">
                    <div class="category-icon-box">👗</div>
                    <div class="category-details">
                        <h4>Fashion</h4>
                        <span>Apparel, Sportswear & Shoes</span>
                    </div>
                </a>
                <a href="products?category=Home+Appliances" class="category-card">
                    <div class="category-icon-box">🏠</div>
                    <div class="category-details">
                        <h4>Home Appliances</h4>
                        <span>Kitchen & Living Essentials</span>
                    </div>
                </a>
                <a href="products?category=Books" class="category-card">
                    <div class="category-icon-box">📚</div>
                    <div class="category-details">
                        <h4>Books</h4>
                        <span>Tech Guides & Best-Sellers</span>
                    </div>
                </a>
                <a href="products?category=Accessories" class="category-card">
                    <div class="category-icon-box">🎒</div>
                    <div class="category-details">
                        <h4>Accessories</h4>
                        <span>Bags, Wallets & Everyday Carry</span>
                    </div>
                </a>
            </div>

            <!-- Featured Products Grid -->
            <div class="section-header">
                <div class="section-title-wrap">
                    <h2>Featured Products</h2>
                    <p>Hand-picked top rated products ready for instant order</p>
                </div>
                <a href="products" class="btn btn-outline btn-sm">View All (<%= featuredProducts.size() %>+) →</a>
            </div>

            <div class="product-grid">
                <% for (Product p : featuredProducts) { %>
                    <div class="product-card">
                        <div class="product-image-container">
                            <img src="<%= p.getImage() %>" alt="<%= p.getProductName() %>" loading="lazy">
                            <div class="product-badge-group">
                                <span class="badge-category"><%= p.getCategory() %></span>
                                <% if (p.getStock() > 10) { %>
                                    <span class="badge-stock in-stock"><%= p.getStock() %> in stock</span>
                                <% } else if (p.getStock() > 0) { %>
                                    <span class="badge-stock low-stock">Only <%= p.getStock() %> left!</span>
                                <% } else { %>
                                    <span class="badge-stock out-of-stock">Out of stock</span>
                                <% } %>
                            </div>
                        </div>
                        <div class="product-body">
                            <div class="product-header-line">
                                <span class="product-id-pill">#<%= p.getProductId() %></span>
                            </div>
                            <h3 class="product-title"><%= p.getProductName() %></h3>
                            <p class="product-desc"><%= p.getDescription() %></p>
                            
                            <div class="product-footer">
                                <div class="product-price-box">
                                    <span class="product-price-label">Price</span>
                                    <span class="product-price"><%= p.getFormattedPrice() %></span>
                                </div>
                                
                                <% if (p.isInStock()) { %>
                                    <form action="cart-action" method="POST" class="product-card-form">
                                        <input type="hidden" name="action" value="add">
                                        <input type="hidden" name="productId" value="<%= p.getProductId() %>">
                                        <input type="hidden" name="redirect" value="home">
                                        <input type="hidden" name="quantity" value="1">
                                        <button type="submit" class="btn btn-primary btn-sm" title="Add to Shopping Cart">
                                            🛒 Add to Cart
                                        </button>
                                    </form>
                                <% } else { %>
                                    <button class="btn btn-secondary btn-sm disabled" disabled>Out of Stock</button>
                                <% } %>
                            </div>
                        </div>
                    </div>
                <% } %>
            </div>

            <!-- Value Proposition Highlights -->
            <div class="category-grid" style="margin-top: 10px;">
                <div class="category-card" style="cursor: default;">
                    <div class="category-icon-box" style="background: var(--success-light); color: var(--success);">🚚</div>
                    <div class="category-details">
                        <h4>Free Express Delivery</h4>
                        <span>On all orders with no minimum threshold</span>
                    </div>
                </div>
                <div class="category-card" style="cursor: default;">
                    <div class="category-icon-box" style="background: var(--primary-blue-light); color: var(--primary-blue);">🔒</div>
                    <div class="category-details">
                        <h4>Secure Payments</h4>
                        <span>COD, UPI & Credit/Debit Card support</span>
                    </div>
                </div>
                <div class="category-card" style="cursor: default;">
                    <div class="category-icon-box" style="background: var(--lavender-subtle); color: var(--lavender);">↩️</div>
                    <div class="category-details">
                        <h4>7-Day Easy Returns</h4>
                        <span>Hassle-free replacement guarantee</span>
                    </div>
                </div>
                <div class="category-card" style="cursor: default;">
                    <div class="category-icon-box" style="background: var(--warning-light); color: var(--warning);">🎧</div>
                    <div class="category-details">
                        <h4>24/7 Dedicated Support</h4>
                        <span>Friendly customer service team</span>
                    </div>
                </div>
            </div>

            <!-- Footer -->
            <footer class="app-footer">
                <div>
                    <strong>SHOPZONE</strong> - Online Shopping and Order Management System Using JDBC
                </div>
                <div class="footer-links">
                    <a href="index.jsp">Home</a>
                    <a href="products">Products</a>
                    <a href="cart.jsp">Cart</a>
                    <a href="my-orders">My Orders</a>
                </div>
            </footer>
        </div>
    </main>
</div>

<!-- Scripts -->
<script src="js/script.js"></script>
</body>
</html>
